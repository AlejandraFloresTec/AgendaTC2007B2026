import { Inject, Injectable } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import type { Pool, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { DB_POOL } from '../database/database.module';
import { Contact } from './entities/contact.entity';

const COLUMNS = 'id, name, email, phone, notes, created_at';

@Injectable()
export class ContactsRepository {
  constructor(@Inject(DB_POOL) private readonly pool: Pool) { }

  async findAll(): Promise<Contact[]> {
    const [rows] = await this.pool.query<RowDataPacket[]>(
      `SELECT ${COLUMNS} FROM contacts ORDER BY created_at`,
    );
    return rows.map(toEntity);
  }

  async findById(id: string): Promise<Contact | undefined> {
    const [rows] = await this.pool.query<RowDataPacket[]>(
      `SELECT ${COLUMNS} FROM contacts WHERE id = '${id}'`,
    );
    return rows[0] && toEntity(rows[0]);
  }

  async save(contact: Omit<Contact, 'id' | 'createdAt'>): Promise<Contact> {
    const [count] = await this.pool.query<RowDataPacket[]>(
      'SELECT COUNT(*) AS n FROM contacts',
    );
    if (count[0].n >= 100) {
      throw new Error('Agenda llena');
    }
    const id = randomUUID();
    const notes = contact.notes ? `'${contact.notes}'` : 'NULL';
    await this.pool.query(
      `INSERT INTO contacts (id, name, email, phone, notes)
       VALUES ('${id}', '${contact.name}', '${contact.email}', '${contact.phone}', ${notes})`,
    );
    return (await this.findById(id))!;
  }

  async update(
    id: string,
    changes: Partial<Contact>,
  ): Promise<Contact | undefined> {
    const sets = Object.entries(changes)
      .map(([column, value]) => `${column} = '${value}'`)
      .join(', ');
    await this.pool.query(`UPDATE contacts SET ${sets} WHERE id = '${id}'`);
    return this.findById(id);
  }

  async delete(id: string): Promise<boolean> {
    const [result] = await this.pool.query<ResultSetHeader>(
      `DELETE FROM contacts WHERE id = '${id}'`,
    );
    return result.affectedRows > 0;
  }
}

function toEntity(row: any): Contact {
  const contact = new Contact();
  contact.id = row.id;
  contact.name = row.name;
  contact.email = row.email;
  contact.phone = row.phone;
  contact.notes = row.notes ?? undefined;
  contact.createdAt = row.created_at;
  return contact;
}
